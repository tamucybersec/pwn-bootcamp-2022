from pwn import *
import subprocess

p = remote("128.199.12.141", 7002)

# automate inputs as necessary here

p.interactive()
