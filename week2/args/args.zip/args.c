#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void win(long arg1, long arg2) {
	if(arg1 == 0xAAAA && arg2 == 0xBBBB) {\
		system("/bin/sh");
	}
}

void vuln() {
	char buf[32];
	gets(buf);
}

void main() {
	setvbuf(stdout, 0, 2, 0);
	vuln();
}