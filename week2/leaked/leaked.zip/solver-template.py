from pwn import *

CHAL = "leaked"

p = remote("128.199.12.141", 7001)

# automate inputs as necessary here

p.interactive()
